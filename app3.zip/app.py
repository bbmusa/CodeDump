from websocketInstrument import OptionDataStreaming
from dotenv import load_dotenv
from pydantic import BaseModel
import os
from zeroMQ import Subscriber
from multiprocessing import Process
import logging
load_dotenv()
import time

def start_subscriber():
    try:
        logging.info("Starting Subscriber...")
        sub = Subscriber()
        sub.listen()
    except Exception as e:
        logging.error(f"Failed to start Subscriber: {e}")


class Setting(BaseModel):
    API_KEY: str = os.getenv('API_KEY')
    API_SECRET: str = os.getenv('API_SECRET')
    REQUEST_TOKEN: str = os.getenv('REQUEST_TOKEN')
    ACCESS_TOKEN: str = os.getenv('ACCESS_TOKEN')


if __name__ == "__main__":
    settings = Setting()
    OptionDataStreaming_process = OptionDataStreaming(settings)
    OptionDataStreaming_process.queue_callBacks()
    Process(target=start_subscriber).start()

